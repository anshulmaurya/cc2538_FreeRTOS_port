
#include "flash_add.h"
//__attribute__((section(".data")))
uint32 flash_addition(uint32 a, uint32 b){

	//uint32 c;
	//c = a+b;
	//c = a-b;
	//c = a/b;
	//c = a<<b;
	//c = a>>b;		
	return a+b;
}
