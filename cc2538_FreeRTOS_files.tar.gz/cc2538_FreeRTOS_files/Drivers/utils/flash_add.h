
#include "hal_types.h"
uint32 flash_addition(uint32 a, uint32 b);
