
#ifndef _IEEE_ADDR_H_
#define _IEEE_ADDR_H_

void getIEEEAddrFrmFlash(uint8_t *ieee_addr);

#endif